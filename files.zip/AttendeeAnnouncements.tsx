import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import type { Announcement, AnnouncementPriority } from '../../types'

/* ─── Icons ─── */
const BellIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
)

/* ─── Helpers ─── */
const STORAGE_KEY = 'festforge_announcements'

const loadAll = (): Announcement[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

const PRIORITY_META: Record<AnnouncementPriority, { label: string; color: string; bg: string; border: string }> = {
  info:    { label: 'Info',    color: '#3B82F6', bg: 'rgba(59,130,246,0.08)',   border: '#3B82F6' },
  warning: { label: 'Warning', color: '#F59E0B', bg: 'rgba(245,158,11,0.08)',  border: '#F59E0B' },
  urgent:  { label: 'Urgent',  color: '#EF4444', bg: 'rgba(239,68,68,0.08)',   border: '#EF4444' },
}

const timeAgo = (iso: string) => {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return `${Math.floor(hrs / 24)}d ago`
}

const fadeUp = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.25, 0.1, 0.25, 1] } },
}
const stagger = { animate: { transition: { staggerChildren: 0.07 } } }

/* ─── Filter types ─── */
type Filter = 'all' | AnnouncementPriority

const AttendeeAnnouncements: React.FC = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [filter, setFilter] = useState<Filter>('all')

  useEffect(() => {
    setAnnouncements(loadAll().sort((a: Announcement, b: Announcement) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()))
    // Poll every 15s for new announcements
    const interval = setInterval(() => {
      setAnnouncements(loadAll().sort((a: Announcement, b: Announcement) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()))
    }, 15000)
    return () => clearInterval(interval)
  }, [])

  const filtered = filter === 'all' ? announcements : announcements.filter((a: Announcement) => a.priority === filter)
  const urgentCount = announcements.filter((a: Announcement) => a.priority === 'urgent').length

  return (
    <motion.div variants={stagger} initial="initial" animate="animate" style={{ maxWidth: 720, margin: '0 auto' }}>
      {/* Header */}
      <motion.div variants={fadeUp} style={{ marginBottom: '1.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem' }}>
              <span style={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '1px', fontWeight: 700, color: 'var(--org-accent-text)' }}>
                Student Portal
              </span>
            </div>
            <h1 style={{ fontSize: '1.6rem', fontWeight: 850, color: 'var(--org-text-primary)', letterSpacing: '-0.03em', margin: 0 }}>
              Announcements
            </h1>
            <p style={{ fontSize: '0.83rem', color: 'var(--org-text-secondary)', marginTop: '0.3rem' }}>
              Stay updated with the latest notices from your event organizers.
            </p>
          </div>

          {urgentCount > 0 && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: '0.4rem',
              background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)',
              borderRadius: '0.6rem', padding: '0.5rem 0.85rem',
              fontSize: '0.78rem', fontWeight: 700, color: '#EF4444',
            }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              {urgentCount} Urgent Alert{urgentCount > 1 ? 's' : ''}
            </div>
          )}
        </div>
      </motion.div>

      {/* Filter tabs */}
      <motion.div variants={fadeUp} style={{ display: 'flex', gap: '0.4rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
        {(['all', 'urgent', 'warning', 'info'] as Filter[]).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: '0.4rem 0.9rem', borderRadius: '2rem',
              border: '1.5px solid',
              borderColor: filter === f
                ? (f === 'all' ? 'var(--org-accent)' : PRIORITY_META[f as AnnouncementPriority].color)
                : 'var(--org-border-default)',
              background: filter === f
                ? (f === 'all' ? 'var(--org-accent-soft)' : PRIORITY_META[f as AnnouncementPriority].bg)
                : 'transparent',
              color: filter === f
                ? (f === 'all' ? 'var(--org-accent-text)' : PRIORITY_META[f as AnnouncementPriority].color)
                : 'var(--org-text-secondary)',
              fontSize: '0.75rem', fontWeight: 700, textTransform: 'capitalize',
              cursor: 'pointer', transition: 'all 0.15s ease',
            }}
          >
            {f === 'all' ? `All (${announcements.length})` : `${f.charAt(0).toUpperCase() + f.slice(1)} (${announcements.filter((a: Announcement) => a.priority === f).length})`}
          </button>
        ))}
      </motion.div>

      {/* Announcements */}
      {filtered.length === 0 ? (
        <motion.div
          variants={fadeUp}
          style={{
            background: 'var(--org-surface-1)',
            border: '1px solid var(--org-border-default)',
            borderRadius: '1rem',
            padding: '3.5rem 2rem',
            textAlign: 'center',
            boxShadow: 'var(--org-shadow-md)',
          }}
        >
          <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>📭</div>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--org-text-primary)', margin: '0 0 0.4rem' }}>
            {filter === 'all' ? 'No announcements yet' : `No ${filter} announcements`}
          </h3>
          <p style={{ fontSize: '0.8rem', color: 'var(--org-text-tertiary)' }}>
            {filter === 'all' ? 'Your organizers haven\'t posted any updates yet. Check back soon!' : `No ${filter}-level notices at the moment.`}
          </p>
        </motion.div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
          {filtered.map((ann: Announcement) => {
            const meta = PRIORITY_META[ann.priority]
            return (
              <motion.div
                key={ann.id}
                variants={fadeUp}
                style={{
                  background: 'var(--org-surface-1)',
                  border: '1px solid var(--org-border-default)',
                  borderLeft: `4px solid ${meta.border}`,
                  borderRadius: '0.85rem',
                  padding: '1.25rem 1.4rem',
                  boxShadow: 'var(--org-shadow-sm)',
                  display: 'flex',
                  gap: '1rem',
                  alignItems: 'flex-start',
                }}
              >
                {/* Icon */}
                <div style={{
                  width: 38, height: 38, borderRadius: '50%',
                  background: meta.bg, display: 'flex',
                  alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, color: meta.color,
                }}>
                  <BellIcon />
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem', flexWrap: 'wrap' }}>
                    <span style={{
                      fontSize: '0.62rem', fontWeight: 750, textTransform: 'uppercase',
                      letterSpacing: '0.7px', color: meta.color,
                      background: meta.bg, padding: '0.12rem 0.45rem', borderRadius: '0.25rem',
                    }}>
                      {meta.label}
                    </span>
                    <h3 style={{ fontSize: '0.92rem', fontWeight: 750, color: 'var(--org-text-primary)', margin: 0 }}>
                      {ann.title}
                    </h3>
                  </div>

                  <p style={{ fontSize: '0.83rem', color: 'var(--org-text-secondary)', lineHeight: 1.55, margin: '0 0 0.6rem' }}>
                    {ann.body}
                  </p>

                  <div style={{ display: 'flex', gap: '0.6rem', alignItems: 'center', fontSize: '0.7rem', color: 'var(--org-text-tertiary)', flexWrap: 'wrap' }}>
                    <span style={{
                      background: 'var(--org-accent-soft)', color: 'var(--org-accent-text)',
                      padding: '0.1rem 0.45rem', borderRadius: '0.3rem', fontWeight: 650, fontSize: '0.68rem',
                    }}>
                      {ann.event_name}
                    </span>
                    <span>·</span>
                    <span>By {ann.organizer_name}</span>
                    <span>·</span>
                    <span>{timeAgo(ann.created_at)}</span>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      )}
    </motion.div>
  )
}

export default AttendeeAnnouncements
