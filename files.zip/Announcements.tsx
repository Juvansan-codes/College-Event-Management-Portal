import React, { useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import PageHeader from '../components/PageHeader'
import StatCard from '../components/StatCard'
import { useEvent } from '../../contexts/EventContext'
import { useAuth } from '../../contexts/AuthContext'
import type { Announcement, AnnouncementPriority } from '../../types'

/* ─── Icons ─── */
const BellIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
)
const UrgentIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
  </svg>
)

/* ─── Helpers ─── */
const STORAGE_KEY = 'festforge_announcements'

const loadAnnouncements = (): Announcement[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

const saveAnnouncements = (list: Announcement[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list))
}

const PRIORITY_META: Record<AnnouncementPriority, { label: string; color: string; bg: string }> = {
  info:    { label: 'Info',    color: 'var(--org-info)',    bg: 'var(--org-info-soft)' },
  warning: { label: 'Warning', color: 'var(--org-warning)', bg: 'var(--org-warning-soft)' },
  urgent:  { label: 'Urgent',  color: 'var(--org-danger)',  bg: 'var(--org-danger-soft)' },
}

const timeAgo = (iso: string) => {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return `${Math.floor(hrs / 24)}d ago`
}

const fadeUp = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.25, 0.1, 0.25, 1] } },
}
const stagger = { animate: { transition: { staggerChildren: 0.06 } } }

/* ─── Main Component ─── */
const Announcements: React.FC = () => {
  const { activeEvent } = useEvent()
  const { user } = useAuth()

  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [showModal, setShowModal] = useState(false)
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [priority, setPriority] = useState<AnnouncementPriority>('info')
  const [deleteId, setDeleteId] = useState<string | null>(null)

  // Load announcements for this event
  useEffect(() => {
    const all = loadAnnouncements()
    setAnnouncements(activeEvent ? all.filter(a => a.event_id === activeEvent.id) : all)
  }, [activeEvent])

  const handlePost = () => {
    if (!title.trim() || !body.trim() || !activeEvent) return
    const newItem: Announcement = {
      id: Date.now().toString(),
      event_id: activeEvent.id,
      event_name: activeEvent.name,
      title: title.trim(),
      body: body.trim(),
      priority,
      created_at: new Date().toISOString(),
      organizer_name: (user as any)?.fullName ?? 'Organizer',
    }
    const all = loadAnnouncements()
    const updated = [newItem, ...all]
    saveAnnouncements(updated)
    setAnnouncements(updated.filter(a => a.event_id === activeEvent.id))
    setTitle('')
    setBody('')
    setPriority('info')
    setShowModal(false)
  }

  const handleDelete = (id: string) => {
    const all = loadAnnouncements()
    const updated = all.filter(a => a.id !== id)
    saveAnnouncements(updated)
    setAnnouncements(updated.filter((a: Announcement) => activeEvent && a.event_id === activeEvent.id))
    setDeleteId(null)
  }

  const urgent = announcements.filter((a: Announcement) => a.priority === 'urgent').length
  const info   = announcements.filter((a: Announcement) => a.priority === 'info').length

  return (
    <motion.div variants={stagger} initial="initial" animate="animate" style={{ padding: '0' }}>
      <PageHeader
        eyebrow="Console"
        title="Announcements"
        subtitle="Broadcast updates, alerts, and notices to all event attendees instantly."
        actions={
          <button className="org-btn org-btn--accent" onClick={() => setShowModal(true)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '0.2rem' }}>
              <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            Post Announcement
          </button>
        }
      />

      {/* Stats */}
      <motion.div variants={fadeUp} style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
        <StatCard icon={<BellIcon />} label="Total Posted" value={announcements.length} colorClass="accent" index={0} />
        <StatCard icon={<UrgentIcon />} label="Urgent Alerts" value={urgent} colorClass="danger" index={1} />
        <StatCard icon={<BellIcon />} label="Info Notices" value={info} colorClass="info" index={2} />
      </motion.div>

      {/* Announcements List */}
      <motion.div variants={fadeUp}>
        <div className="org-section__header">
          <div>
            <h2 className="org-section__title">Posted Announcements</h2>
            <p className="org-section__subtitle">All broadcasts sent to attendees for this event.</p>
          </div>
        </div>

        {announcements.length === 0 ? (
          <div className="org-surface org-surface--elevated" style={{ padding: '3rem', textAlign: 'center' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>📢</div>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--org-text-primary)', marginBottom: '0.4rem' }}>No announcements yet</h3>
            <p style={{ fontSize: '0.83rem', color: 'var(--org-text-tertiary)' }}>Post your first announcement to keep attendees informed.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
            <AnimatePresence>
              {announcements.map((ann: Announcement) => {
                const meta = PRIORITY_META[ann.priority]
                return (
                  <motion.div
                    key={ann.id}
                    layout
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="org-surface org-surface--elevated"
                    style={{
                      padding: '1.25rem 1.5rem',
                      borderLeft: `3px solid ${meta.color}`,
                      display: 'flex',
                      gap: '1rem',
                      alignItems: 'flex-start',
                    }}
                  >
                    {/* Priority dot */}
                    <div style={{
                      width: 36, height: 36, borderRadius: '50%',
                      background: meta.bg, display: 'flex',
                      alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0, color: meta.color,
                    }}>
                      <BellIcon />
                    </div>

                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem', flexWrap: 'wrap' }}>
                        <span style={{
                          fontSize: '0.65rem', fontWeight: 750, textTransform: 'uppercase',
                          letterSpacing: '0.7px', color: meta.color,
                          background: meta.bg, padding: '0.15rem 0.5rem', borderRadius: '0.3rem',
                        }}>
                          {meta.label}
                        </span>
                        <h3 style={{ fontSize: '0.93rem', fontWeight: 750, color: 'var(--org-text-primary)', margin: 0 }}>
                          {ann.title}
                        </h3>
                      </div>
                      <p style={{ fontSize: '0.82rem', color: 'var(--org-text-secondary)', lineHeight: 1.5, marginBottom: '0.6rem' }}>
                        {ann.body}
                      </p>
                      <div style={{ fontSize: '0.7rem', color: 'var(--org-text-tertiary)', display: 'flex', gap: '0.8rem' }}>
                        <span>By {ann.organizer_name}</span>
                        <span>·</span>
                        <span>{timeAgo(ann.created_at)}</span>
                      </div>
                    </div>

                    {/* Delete */}
                    <button
                      className="org-btn org-btn--ghost"
                      onClick={() => setDeleteId(ann.id)}
                      style={{ padding: '0.35rem', color: 'var(--org-text-tertiary)', flexShrink: 0 }}
                      title="Delete"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                        <path d="M10 11v6" /><path d="M14 11v6" /><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                      </svg>
                    </button>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </div>
        )}
      </motion.div>

      {/* Create Modal */}
      {createPortal(
        <AnimatePresence>
          {showModal && (
            <motion.div className="org-modal-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowModal(false)}>
              <motion.div className="org-modal" initial={{ opacity: 0, y: 20, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.98 }} transition={{ duration: 0.28 }} onClick={(e: React.MouseEvent) => e.stopPropagation()}>
                <div className="org-modal__header">
                  <h2 className="org-modal__title">Post Announcement</h2>
                  <button className="org-modal__close" onClick={() => setShowModal(false)}>×</button>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
                  {/* Priority selector */}
                  <div>
                    <div className="org-label" style={{ marginBottom: '0.5rem' }}>Priority Level</div>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      {(['info', 'warning', 'urgent'] as AnnouncementPriority[]).map(p => {
                        const m = PRIORITY_META[p]
                        const active = priority === p
                        return (
                          <button
                            key={p}
                            onClick={() => setPriority(p)}
                            style={{
                              flex: 1, padding: '0.5rem 0.75rem', borderRadius: '0.5rem', border: `1.5px solid`,
                              borderColor: active ? m.color : 'var(--org-border-default)',
                              background: active ? m.bg : 'transparent',
                              color: active ? m.color : 'var(--org-text-secondary)',
                              fontSize: '0.78rem', fontWeight: 700, cursor: 'pointer', transition: 'all 0.15s ease',
                            }}
                          >
                            {m.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  <label className="org-label">
                    Title
                    <input className="org-input" placeholder="e.g. Venue change for Hall B" value={title} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTitle(e.target.value)} />
                  </label>

                  <label className="org-label">
                    Message
                    <textarea
                      className="org-input"
                      placeholder="Write your announcement here..."
                      value={body}
                      onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setBody(e.target.value)}
                      rows={4}
                      style={{ resize: 'vertical' }}
                    />
                  </label>
                </div>

                <div className="org-modal__footer">
                  <button className="org-btn org-btn--secondary" onClick={() => setShowModal(false)}>Cancel</button>
                  <button className="org-btn org-btn--accent" onClick={handlePost} disabled={!title.trim() || !body.trim()}>
                    Post Announcement
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}

      {/* Delete Confirm Modal */}
      {createPortal(
        <AnimatePresence>
          {deleteId && (
            <motion.div className="org-modal-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setDeleteId(null)}>
              <motion.div className="org-modal" style={{ maxWidth: 400 }} initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }} transition={{ duration: 0.22 }} onClick={(e: React.MouseEvent) => e.stopPropagation()}>
                <div className="org-modal__header">
                  <h2 className="org-modal__title">Delete Announcement?</h2>
                  <button className="org-modal__close" onClick={() => setDeleteId(null)}>×</button>
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--org-text-secondary)', padding: '0.5rem 0' }}>
                  This will permanently remove the announcement from the attendee feed.
                </p>
                <div className="org-modal__footer">
                  <button className="org-btn org-btn--secondary" onClick={() => setDeleteId(null)}>Cancel</button>
                  <button className="org-btn" style={{ background: 'var(--org-danger)', color: '#fff' }} onClick={() => handleDelete(deleteId!)}>
                    Delete
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </motion.div>
  )
}

export default Announcements
